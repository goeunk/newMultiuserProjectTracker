using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace SignalRChat.Hubs
{
    public class ChatHub : Hub
    {

        DatabaseSuff db = new DatabaseSuff();

        public override async Task OnConnectedAsync()
        {
            List<TextArea> list = db.selectAll();
            foreach(TextArea textArea in list){
                await Clients.Caller.SendAsync("CreateNewTextBox", textArea.id, textArea.text);
            }
        
        }
        public async Task SendMessage(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        public async Task UpdateTextBox(string textboxID, string message){
            db.update(textboxID, message);
            await Clients.Others.SendAsync("UpdateText", textboxID, message);
        }

        public async Task LockText(string textboxID){
            
            await Clients.Others.SendAsync("LockTextBox", textboxID);
        }

        public async Task UnlockText(string textboxID){
            await Clients.Others.SendAsync("UnlockText", textboxID);
        }
        public async Task CreateNewTextBox(){
            db.insert("new text box wahoooooo");
            int id = db.getLastID();
            await Clients.All.SendAsync("CreateNewTextBox", id, "new text box wahoooooo");
        }
    }
}