public class TextArea {
    public string text;
    public int id;

    public TextArea(string text, int id){
        this.id = id;
        this.text = text;

    }



}