using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;


public class DatabaseSuff {
    string connectionString = "Server=cs3750serv.database.windows.net;Database=cs3750data;User ID=kenziek; Password=PWRdunamis09!";
    SqlConnection connection = new SqlConnection("Server=cs3750serv.database.windows.net;Database=cs3750data;User ID=kenziek; Password=PWRdunamis09!");
    public void insert(string Text){
            
            using(SqlConnection cnn = new SqlConnection(connectionString))
            {
            string sql = "INSERT INTO groupSession (textArea) VALUES (@textString)";
            cnn.Open();
                using(SqlCommand cmd = new SqlCommand(sql, cnn))
                {
                    cmd.Parameters.AddWithValue("@textString", Text);
                    int numRows = cmd.ExecuteNonQuery();
                }
            }


    }

    public void update(string ID, string Text){
            
            using(SqlConnection cnn = new SqlConnection(connectionString))
            {
            string updateSQL = "UPDATE groupSession SET textArea = @textString WHERE id = @id";
            cnn.Open();
            using(SqlCommand cmd = new SqlCommand(updateSQL, cnn))
            {
                int idAsInt = Int32.Parse(ID);
                cmd.Parameters.AddWithValue("@id", idAsInt);
                cmd.Parameters.AddWithValue("@textString", Text);
                int numRows = cmd.ExecuteNonQuery();
                
            }
            }
    }

    public List<TextArea> selectAll(){
        
        using (SqlConnection cnn = new SqlConnection(connectionString))
        {
            string selectStmt = "SELECT * FROM groupSession";
            SqlCommand command = new SqlCommand(selectStmt, cnn);
            cnn.Open();
            
            using (SqlDataReader reader = command.ExecuteReader())
            {
                List<TextArea> list = new List<TextArea>();
                while (reader.Read())
                {    
                    string text = reader.GetString(reader.GetOrdinal("textArea")); 
                    int id = reader.GetInt32(reader.GetOrdinal("id")); 
                    TextArea temp = new TextArea(text, id);  
                    list.Add(temp);     
                }

                cnn.Close();
                return list;
            }
            
            
                           
        }
            
        
    }



    public int getLastID(){
        
        using (SqlConnection cnn = new SqlConnection(connectionString))
        {
            string selectStmt = "SELECT * FROM groupSession ORDER BY id DESC";
            SqlCommand command = new SqlCommand(selectStmt, cnn);
            cnn.Open();
            
            using (SqlDataReader reader = command.ExecuteReader())
            {
                int id = 0;
                while (reader.Read() && id == 0)
                {    
                    id = reader.GetInt32(reader.GetOrdinal("id")); 
                    
                       
                }

                cnn.Close();
                return id;
            }
            
            
                           
        }
            
        
    }

    


}