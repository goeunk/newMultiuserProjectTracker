﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace newMultiuserProjectTracker.Pages
{
    public class IndexModel : PageModel{   
        // string connectionString = "Server=cs3750serv.database.windows.net;Database=cs3750data;User ID=kenziek; Password=PWRdunamis09!";
        // SqlConnection connection = new SqlConnection("Server=cs3750serv.database.windows.net;Database=cs3750data;User ID=kenziek; Password=PWRdunamis09!");

        // public string Message { get; private set; } = "Message:  ";

        // public int ID {get; private set;} = 0;
        // public string Group {get; private set; } = "Group";
        // public string Text {get; private set; } ="";
        // public int rowsEffected;

        // public void OnGet()
        // {
        //     Message+="Love is the answer!";
        //     openDatabase();
        //     select();
        //     close();
        // }

        // public void OnPost(){
        //     OnGet();
        //     Group = Request.Form["Name"];
        //     ViewData["confirmation"] = $"{Group}";
        //     insert();
        //     select();
        // }

        // public void insert(){
        //     openDatabase();
        //     string sql = "INSERT INTO groupSession (ID, groupName, textBox) VALUES ('" + ID + "','" + Group + "', '" + Text + "' )";
        //     SqlCommand cmd = new SqlCommand(sql, connection);
        //     SqlDataAdapter adapter = new SqlDataAdapter();
        //     cmd.ExecuteNonQuery();
        // }

        // public void openDatabase(){
        //     connection.Open();
        // }

        // public void select(){
        //  SqlCommand cmd = new SqlCommand("SELECT * FROM groupSession", connection);
        //  SqlDataReader dr = cmd.ExecuteReader();

        //     string x = "";
        //     string y = "";
        //     string z = "";

        //     while (dr.Read())
        //     {
        //         x = "Your Group is" + dr["groupName"].ToString() + " " + dr["textBox"];
        //         y = "You chose ";

        //         if (dr["ID"].ToString() == "0")
        //         {
        //             z = "A ";
        //         }
        //     }
        //     var count = x + y + z;

        //     Message += count;      
        // }

        // public void close(){
        //     connection.Close();
        // }
    }
}
