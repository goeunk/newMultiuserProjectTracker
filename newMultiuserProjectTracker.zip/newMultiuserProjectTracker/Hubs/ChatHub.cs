using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace SignalRChat.Hubs
{
    public class ChatHub : Hub
    {
        public async Task SendMessage(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        public async Task UpdateTextBox(string textboxID, string message){
        
            await Clients.Others.SendAsync("UpdateText", textboxID, message);
        }

        public async Task LockText(string textboxID){
            await Clients.Others.SendAsync("LockTextBox", textboxID);
        }

        public async Task UnlockText(string textboxID){
            await Clients.Others.SendAsync("UnlockText", textboxID);
        }
    }
}