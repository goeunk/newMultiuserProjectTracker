"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();

connection.start().catch(function (err) {
    return console.error(err.toString());
});

connection.on("UpdateText", function (textboxID, message){
    console.log("update text: " + message);
    document.getElementById(textboxID).value = message;
});


connection.on("LockTextBox", function (textBoxID){
    console.log("text box is locked : " + textBoxID);
    document.getElementById(textBoxID).disabled = true;
});

connection.on("UnlockText", function (textBoxID) {
    console.log("text box is unlocked : " + textBoxID);
    document.getElementById(textBoxID).disabled = false;
});

var onKeyupFunction = function(event){
    var element = this.id
    var text = this.value
    //console.log(event);
    //console.log("element id : " + element)
    connection.invoke("UpdateTextBox", element, text).catch(function (err) {
        return console.error(err.toString);
    });
};

var onFocus = function(event){
    var elementID = this.id
    connection.invoke("LockText", elementID).catch(function (err) {
        return console.error(err.toString);
    });
};

var onBlur = function(event){
    var elementID = this.id
    connection.invoke("UnlockText", elementID).catch(function (err) {
        return console.error(err.toString);
    });
}

document.getElementById("messagesList").addEventListener("keyup", onKeyupFunction);
document.getElementById("messagesList").addEventListener("focus", onFocus);
document.getElementById("messagesList").addEventListener("blur", onBlur);


